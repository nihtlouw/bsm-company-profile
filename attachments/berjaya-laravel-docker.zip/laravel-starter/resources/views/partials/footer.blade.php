<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
                <img src="{{ asset('assets/logo-bsm.png') }}" alt="Logo PT Berjaya Sukses Makmur" style="height:44px;width:auto;">
                <strong style="color:#fff;">PT. Berjaya Sukses Makmur</strong>
            </div>
            <p>General contractor &amp; supplier &mdash; fokus electrical engineering &amp; installation.</p>
        </div>
    </div>
    <div class="container footer-bottom">
        <span>&copy; {{ date('Y') }} PT Berjaya Sukses Makmur.</span>
    </div>
</footer>
