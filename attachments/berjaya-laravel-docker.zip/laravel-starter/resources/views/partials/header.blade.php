<header class="site-header" id="siteHeader">
    <div class="container nav-row">
        <a href="{{ route('home') }}" class="brand">
            <img class="brand-mark-img" src="{{ asset('assets/logo-bsm.png') }}" alt="Logo PT Berjaya Sukses Makmur">
            <span class="brand-text">
                <strong>PT. Berjaya Sukses Makmur</strong>
                <span>General Contractor &amp; Supplier</span>
            </span>
        </a>
        <nav class="nav-links" id="navLinks">
            <a href="{{ route('home') }}#home" data-nav>Home</a>
            <a href="{{ route('home') }}#about">About Us</a>
            <a href="{{ route('home') }}#services">Services</a>
            <a href="{{ route('home') }}#projects" data-nav>Projects</a>
            <a href="{{ route('home') }}#contact">Contact</a>
        </nav>
        <a href="{{ route('home') }}#contact" class="btn btn-outline-navy">Hubungi Kami</a>
    </div>
</header>
