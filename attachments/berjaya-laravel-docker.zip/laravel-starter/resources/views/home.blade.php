@extends('layouts.app')

@section('title', 'PT Berjaya Sukses Makmur — Electrical Engineering & Installation')

@section('content')
<section id="home" class="hero">
    <div class="container hero-grid">
        <div>
            <span class="badge">SEJAK 2010 &middot; PALEMBANG &amp; KARAWANG</span>
            <h1>Electrical Engineering &amp; Installation</h1>
            <p class="lead">Kontraktor elektrikal untuk rumah sakit, pabrik, dan gedung komersial.</p>
            <a href="#projects" class="btn btn-primary">Lihat Proyek</a>
        </div>
    </div>
</section>

<section id="projects" class="section" x-data="{ filter: 'semua' }">
    <div class="container">
        <div class="section-head">
            <h2>Portofolio Proyek</h2>
        </div>

        <div class="filter-row">
            <button @click="filter = 'semua'" :class="{ active: filter === 'semua' }" class="filter-btn">Semua</button>
            <button @click="filter = 'rumah-sakit'" :class="{ active: filter === 'rumah-sakit' }" class="filter-btn">Rumah Sakit</button>
            <button @click="filter = 'pabrik'" :class="{ active: filter === 'pabrik' }" class="filter-btn">Pabrik</button>
            <button @click="filter = 'gedung'" :class="{ active: filter === 'gedung' }" class="filter-btn">Gedung Komersial</button>
        </div>

        <div class="portfolio-grid">
            @foreach ($projects as $project)
                <article class="p-card"
                         x-show="filter === 'semua' || filter === '{{ $project->category }}'"
                         x-transition>
                    <div class="p-banner">
                        @if ($project->cover_image)
                            <img src="{{ asset('storage/' . $project->cover_image) }}" alt="{{ $project->title }}">
                        @endif
                    </div>
                    <div class="p-body">
                        <h3>{{ $project->title }}</h3>
                        <p class="sub">{{ $project->subtitle }}</p>
                        <button type="button"
                                @click="$dispatch('open-case-modal', {
                                    title: '{{ $project->title }}',
                                    background: '{{ $project->background }}',
                                    solution: '{{ $project->solution }}',
                                    result: '{{ $project->result }}'
                                })">
                            Lihat studi kasus &rarr;
                        </button>
                    </div>
                </article>
            @endforeach
        </div>
    </div>
</section>

<section id="contact" class="section">
    <div class="container">
        @if (session('success'))
            <div class="form-success show">{{ session('success') }}</div>
        @endif

        <form method="POST" action="{{ route('contact.store') }}" class="form-card">
            @csrf
            <div class="field">
                <label for="name">Nama Lengkap</label>
                <input type="text" id="name" name="name" value="{{ old('name') }}">
                @error('name') <span class="field-error" style="display:block">{{ $message }}</span> @enderror
            </div>
            <div class="field">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="{{ old('email') }}">
                @error('email') <span class="field-error" style="display:block">{{ $message }}</span> @enderror
            </div>
            <div class="field">
                <label for="company">Perusahaan</label>
                <input type="text" id="company" name="company" value="{{ old('company') }}">
                @error('company') <span class="field-error" style="display:block">{{ $message }}</span> @enderror
            </div>
            <div class="field">
                <label for="message">Pesan</label>
                <textarea id="message" name="message">{{ old('message') }}</textarea>
                @error('message') <span class="field-error" style="display:block">{{ $message }}</span> @enderror
            </div>
            <button type="submit" class="btn btn-primary btn-block">Kirim Pesan</button>
        </form>
    </div>
</section>
@endsection
