<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'PT Berjaya Sukses Makmur')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    @include('partials.header')

    <main>
        @yield('content')
    </main>

    @include('partials.footer')

    <div class="modal-overlay" id="modalOverlay">
        <div class="modal-box" id="modalBox" role="dialog" aria-modal="true"></div>
    </div>
    <div id="toast" class="toast" role="status" aria-live="polite"></div>

    <script src="{{ asset('js/script.js') }}"></script>
</body>
</html>
