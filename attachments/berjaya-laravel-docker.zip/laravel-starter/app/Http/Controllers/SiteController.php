<?php

namespace App\Http\Controllers;

use App\Models\Certification;
use App\Models\ClientLogo;
use App\Models\Project;
use App\Models\Testimonial;
use Illuminate\Http\Request;

class SiteController extends Controller
{
    public function home(Request $request)
    {
        $projects = Project::published()
            ->category($request->query('category'))
            ->latest()
            ->get();

        $certifications = Certification::where('is_published', true)->get();
        $clients = ClientLogo::where('is_published', true)->get();

        return view('home', compact('projects', 'certifications', 'clients'));
    }

    public function campaign()
    {
        $testimonials = Testimonial::where('is_published', true)->latest()->take(2)->get();

        return view('campaign', compact('testimonials'));
    }
}
