<?php

namespace App\Http\Controllers;

use App\Models\ContactMessage;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'company' => 'required|string|max:255',
            'message' => 'required|string',
        ]);

        ContactMessage::create($data + ['source' => 'contact_form']);

        return back()->with('success', 'Pesan terkirim. Tim kami akan menghubungi Anda dalam 1x24 jam.');
    }

    public function storeLead(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:30',
            'project_type' => 'required|string|max:255',
            'location' => 'required|string|max:255',
        ]);

        ContactMessage::create([
            'name' => $data['name'],
            'message' => "Jenis proyek: {$data['project_type']}. Lokasi: {$data['location']}. No. WA: {$data['phone']}.",
            'source' => 'campaign_lead',
        ]);

        return back()->with('success', 'Permintaan terkirim! Tim kami akan segera menghubungi Anda.');
    }
}
