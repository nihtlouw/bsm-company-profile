<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProjectResource\Pages;
use App\Models\Project;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class ProjectResource extends Resource
{
    protected static ?string $model = Project::class;
    protected static ?string $navigationIcon = 'heroicon-o-briefcase';
    protected static ?string $navigationGroup = 'Konten Website';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('title')->required(),
            Forms\Components\Select::make('category')
                ->options([
                    'rumah-sakit' => 'Rumah Sakit',
                    'pabrik' => 'Pabrik',
                    'gedung' => 'Gedung Komersial',
                ])
                ->required(),
            Forms\Components\TextInput::make('subtitle'),
            Forms\Components\Textarea::make('background')->label('Latar Belakang'),
            Forms\Components\Textarea::make('solution')->label('Solusi'),
            Forms\Components\Textarea::make('result')->label('Hasil'),
            Forms\Components\FileUpload::make('cover_image')->image()->directory('projects'),
            Forms\Components\Toggle::make('is_published')->label('Tampilkan di Website')->default(true),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('title')->searchable(),
            Tables\Columns\TextColumn::make('category'),
            Tables\Columns\IconColumn::make('is_published')->boolean(),
            Tables\Columns\TextColumn::make('updated_at')->dateTime('d M Y'),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProjects::route('/'),
            'create' => Pages\CreateProject::route('/create'),
            'edit' => Pages\EditProject::route('/{record}/edit'),
        ];
    }
}
