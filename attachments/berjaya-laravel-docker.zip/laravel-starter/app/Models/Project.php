<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'category',      // rumah-sakit | pabrik | gedung
        'subtitle',
        'background',
        'solution',
        'result',
        'cover_image',
        'is_published',
    ];

    protected $casts = [
        'is_published' => 'boolean',
    ];

    public function scopePublished($query)
    {
        return $query->where('is_published', true);
    }

    public function scopeCategory($query, ?string $category)
    {
        if (!$category || $category === 'semua') {
            return $query;
        }
        return $query->where('category', $category);
    }
}
