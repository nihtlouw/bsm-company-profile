<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientLogo extends Model
{
    protected $fillable = ['client_name', 'logo_path', 'is_published'];

    protected $casts = ['is_published' => 'boolean'];
}
