<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Certification extends Model
{
    protected $fillable = ['name', 'description', 'document_path', 'is_published'];

    protected $casts = ['is_published' => 'boolean'];
}
