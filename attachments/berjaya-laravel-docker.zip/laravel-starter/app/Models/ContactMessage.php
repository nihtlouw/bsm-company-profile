<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContactMessage extends Model
{
    protected $fillable = ['name', 'email', 'company', 'message', 'source', 'is_read'];

    protected $casts = ['is_read' => 'boolean'];
}
