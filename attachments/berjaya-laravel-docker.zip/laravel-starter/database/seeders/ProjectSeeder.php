<?php

namespace Database\Seeders;

use App\Models\Project;
use Illuminate\Database\Seeder;

class ProjectSeeder extends Seeder
{
    public function run(): void
    {
        $projects = [
            [
                'title' => 'RSPAD',
                'category' => 'rumah-sakit',
                'subtitle' => 'Panel distribusi rumah sakit',
                'background' => 'Unit rawat inap baru membutuhkan panel distribusi yang andal dengan cadangan daya untuk ruang kritis.',
                'solution' => 'Pemasangan panel distribusi utama beserta sistem daya darurat untuk area perawatan intensif.',
                'result' => 'Commissioning selesai tepat waktu dan sistem lolos uji beban penuh sebelum serah terima.',
            ],
            [
                'title' => 'Factory',
                'category' => 'pabrik',
                'subtitle' => 'Instalasi pabrik manufaktur',
                'background' => 'Lini produksi baru membutuhkan jaringan listrik dan grounding sesuai standar sebelum mulai beroperasi.',
                'solution' => 'Instalasi kabel, pemasangan Motor Control Center (MCC), dan pengujian FAT sebelum commissioning.',
                'result' => 'Produksi mulai berjalan sesuai jadwal tanpa insiden kelistrikan.',
            ],
            [
                'title' => 'Commercial Building',
                'category' => 'gedung',
                'subtitle' => 'Gedung perkantoran 12 lantai',
                'background' => 'Gedung 12 lantai membutuhkan distribusi listrik per lantai yang terkoordinasi dengan tim MEP lain.',
                'solution' => 'Pemasangan panel distribusi tiap lantai beserta sistem penerangan yang terintegrasi.',
                'result' => 'Serah terima proyek tepat waktu dan terintegrasi mulus dengan sistem gedung lainnya.',
            ],
            [
                'title' => 'Puskesmas Kecamatan',
                'category' => 'rumah-sakit',
                'subtitle' => 'Instalasi kelistrikan fasilitas kesehatan',
                'background' => 'Fasilitas kesehatan tingkat kecamatan membutuhkan sistem kelistrikan yang andal untuk peralatan medis dasar.',
                'solution' => 'Instalasi kelistrikan, pencahayaan darurat, dan sistem grounding sesuai standar.',
                'result' => 'Operasional berjalan tanpa gangguan berarti sejak commissioning.',
            ],
            [
                'title' => 'Pabrik Elektronik',
                'category' => 'pabrik',
                'subtitle' => 'Panel & grounding area produksi',
                'background' => 'Area produksi yang sensitif terhadap gangguan listrik membutuhkan panel kontrol presisi.',
                'solution' => 'Pemasangan panel kontrol otomatis berbasis PLC dengan sistem grounding khusus anti-noise.',
                'result' => 'Tingkat gangguan produksi akibat noise listrik menurun signifikan.',
            ],
        ];

        foreach ($projects as $project) {
            Project::create($project);
        }
    }
}
