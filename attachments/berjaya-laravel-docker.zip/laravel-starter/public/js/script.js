(function(){
  var WA_NUMBER = "6281234567890";
  var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var isTouch = 'ontouchstart' in window;

  /* ---------- Toast ---------- */
  var toastEl = document.getElementById('toast');
  var toastTimer;
  function showToast(msg){
    if(!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function(){ toastEl.classList.remove('show'); }, 3200);
  }

  /* ---------- Modal ---------- */
  var modalOverlay = document.getElementById('modalOverlay');
  var modalBox = document.getElementById('modalBox');
  function openModal(html){
    if(!modalOverlay || !modalBox) return;
    modalBox.innerHTML = html;
    modalOverlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    var closeBtn = modalBox.querySelector('[data-modal-close]');
    if(closeBtn) closeBtn.addEventListener('click', closeModal);
  }
  function closeModal(){
    if(!modalOverlay) return;
    modalOverlay.classList.remove('open');
    document.body.style.overflow = '';
  }
  if(modalOverlay){
    modalOverlay.addEventListener('click', function(e){ if(e.target === modalOverlay) closeModal(); });
  }
  document.addEventListener('keydown', function(e){ if(e.key === 'Escape') closeModal(); });

  /* ---------- 3D tilt-on-hover ---------- */
  function attachTilt(el, max, lift, scale){
    el.addEventListener('mousemove', function(e){
      var rect = el.getBoundingClientRect();
      var px = ((e.clientX - rect.left) / rect.width) - 0.5;
      var py = ((e.clientY - rect.top) / rect.height) - 0.5;
      var rotateY = px * max * 2;
      var rotateX = -py * max * 2;
      el.style.transform = 'perspective(800px) rotateX(' + rotateX + 'deg) rotateY(' + rotateY + 'deg) translateY(-' + lift + 'px) scale(' + scale + ')';
    });
    el.addEventListener('mouseleave', function(){ el.style.transform = ''; });
  }
  if(!prefersReduced && !isTouch){
    document.querySelectorAll('.service-card, .p-card, .doc-card, .gallery-tile').forEach(function(el){ attachTilt(el, 6, 5, 1.015); });
    var panelCardEl = document.getElementById('panelCard');
    if(panelCardEl) attachTilt(panelCardEl, 10, 0, 1.01);
  }

  /* ---------- Case study data (used on index.html) ---------- */
  var CASE_STUDIES = {
    rspad: { tag:'Rumah Sakit', title:'RSPAD — Panel Distribusi Rumah Sakit',
      latar:'Unit rawat inap baru membutuhkan panel distribusi yang andal dengan cadangan daya untuk ruang kritis.',
      solusi:'Pemasangan panel distribusi utama beserta sistem daya darurat untuk area perawatan intensif.',
      hasil:'Commissioning selesai tepat waktu dan sistem lolos uji beban penuh sebelum serah terima.' },
    factory: { tag:'Pabrik', title:'Factory — Instalasi Pabrik Manufaktur',
      latar:'Lini produksi baru membutuhkan jaringan listrik dan grounding sesuai standar sebelum mulai beroperasi.',
      solusi:'Instalasi kabel, pemasangan Motor Control Center (MCC), dan pengujian FAT sebelum commissioning.',
      hasil:'Produksi mulai berjalan sesuai jadwal tanpa insiden kelistrikan.' },
    commercial: { tag:'Gedung Komersial', title:'Commercial Building — Gedung Perkantoran 12 Lantai',
      latar:'Gedung 12 lantai membutuhkan distribusi listrik per lantai yang terkoordinasi dengan tim MEP lain.',
      solusi:'Pemasangan panel distribusi tiap lantai beserta sistem penerangan yang terintegrasi.',
      hasil:'Serah terima proyek tepat waktu dan terintegrasi mulus dengan sistem gedung lainnya.' },
    puskesmas: { tag:'Rumah Sakit', title:'Puskesmas Kecamatan — Instalasi Kelistrikan Fasilitas Kesehatan',
      latar:'Fasilitas kesehatan tingkat kecamatan membutuhkan sistem kelistrikan yang andal untuk peralatan medis dasar.',
      solusi:'Instalasi kelistrikan, pencahayaan darurat, dan sistem grounding sesuai standar.',
      hasil:'Operasional berjalan tanpa gangguan berarti sejak commissioning.' },
    'pabrik-elektronik': { tag:'Pabrik', title:'Pabrik Elektronik — Panel &amp; Grounding Area Produksi',
      latar:'Area produksi yang sensitif terhadap gangguan listrik membutuhkan panel kontrol presisi.',
      solusi:'Pemasangan panel kontrol otomatis berbasis PLC dengan sistem grounding khusus anti-noise.',
      hasil:'Tingkat gangguan produksi akibat noise listrik menurun signifikan.' }
  };
  document.querySelectorAll('[data-case-trigger]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var card = btn.closest('.p-card');
      var cs = CASE_STUDIES[card.getAttribute('data-id')];
      if(!cs) return;
      openModal(
        '<button class="modal-close" data-modal-close aria-label="Tutup">&times;</button>'+
        '<div class="modal-eyebrow">'+cs.tag+'</div>'+
        '<h3>'+cs.title+'</h3>'+
        '<div class="modal-section"><h5>Latar Belakang</h5><p>'+cs.latar+'</p></div>'+
        '<div class="modal-section"><h5>Solusi</h5><p>'+cs.solusi+'</p></div>'+
        '<div class="modal-section"><h5>Hasil</h5><p>'+cs.hasil+'</p></div>'
      );
    });
  });

  /* ---------- Document cards ---------- */
  document.querySelectorAll('[data-doc-trigger]').forEach(function(btn){
    btn.addEventListener('click', function(){ showToast('Dokumen akan tampil di sini setelah diupload lewat panel CRM.'); });
  });

  /* ---------- Gallery ---------- */
  document.querySelectorAll('.gallery-tile').forEach(function(tile){
    tile.addEventListener('click', function(){
      var caption = tile.getAttribute('data-caption');
      openModal(
        '<button class="modal-close" data-modal-close aria-label="Tutup">&times;</button>'+
        '<div class="modal-eyebrow">Galeri Foto PT</div>'+
        '<h3>'+caption+'</h3>'+
        '<div class="modal-section"><p>Slot foto — upload gambar aslinya lewat panel CRM untuk menggantikan placeholder ini.</p></div>'
      );
    });
  });

  /* ---------- Hero panel switch grid + living blink (index.html only) ---------- */
  var panelGrid = document.getElementById('panelGrid');
  if(panelGrid){
    var switches = [];
    [1,0,1,1,0,0,1,0,1,1].forEach(function(on){
      var d = document.createElement('div');
      d.className = 'panel-switch' + (on ? ' on' : '');
      panelGrid.appendChild(d);
      switches.push(d);
    });
    if(!prefersReduced){
      setInterval(function(){
        var i = Math.floor(Math.random()*switches.length);
        switches[i].classList.toggle('on');
      }, 1100);
    }
  }

  /* ---------- Mobile menu (index.html only) ---------- */
  var menuToggle = document.getElementById('menuToggle');
  var mobilePanel = document.getElementById('mobilePanel');
  if(menuToggle && mobilePanel){
    menuToggle.addEventListener('click', function(){
      var open = mobilePanel.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.querySelectorAll('#mobilePanel a').forEach(function(a){
      a.addEventListener('click', function(){ mobilePanel.classList.remove('open'); });
    });
  }

  /* ---------- Header scroll shadow (index.html only) ---------- */
  var header = document.getElementById('siteHeader');
  if(header){
    window.addEventListener('scroll', function(){
      header.classList.toggle('scrolled', window.scrollY > 12);
    }, { passive:true });
  }

  /* ---------- Active nav link on scroll ---------- */
  var navLinks = document.querySelectorAll('[data-nav]');
  var sectionIds = ['home','services','projects','legalitas','galeri','about','clients','contact'];
  var sections = sectionIds.map(function(id){ return document.getElementById(id); }).filter(Boolean);
  if(sections.length && navLinks.length){
    var navObserver = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting){
          var id = entry.target.id;
          navLinks.forEach(function(l){ l.classList.toggle('active', l.getAttribute('href') === '#' + id); });
        }
      });
    }, { rootMargin: '-45% 0px -45% 0px' });
    sections.forEach(function(s){ navObserver.observe(s); });
  }

  /* ---------- Scroll reveal ---------- */
  var revealTargets = document.querySelectorAll('.reveal, .reveal-stagger');
  if(revealTargets.length){
    var revealObserver = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting){ entry.target.classList.add('in'); revealObserver.unobserve(entry.target); }
      });
    }, { threshold:.15 });
    revealTargets.forEach(function(el){
      if(prefersReduced){ el.classList.add('in'); } else { revealObserver.observe(el); }
    });
  }

  /* ---------- Stat counters ---------- */
  function animateCounter(el){
    var target = parseFloat(el.getAttribute('data-target'));
    var suffix = el.getAttribute('data-suffix') || '';
    var isDecimal = target % 1 !== 0;
    if(prefersReduced){ el.textContent = target + suffix; return; }
    var duration = 1200, startTime = null;
    function step(ts){
      if(!startTime) startTime = ts;
      var progress = Math.min((ts - startTime) / duration, 1);
      var val = isDecimal ? (progress*target).toFixed(1) : Math.floor(progress*target);
      el.textContent = val + suffix;
      if(progress < 1) requestAnimationFrame(step); else el.textContent = target + suffix;
    }
    requestAnimationFrame(step);
  }
  var statEls = document.querySelectorAll('.stat-num');
  if(statEls.length){
    var counterObserver = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting){ animateCounter(entry.target); counterObserver.unobserve(entry.target); }
      });
    }, { threshold:.4 });
    statEls.forEach(function(el){ counterObserver.observe(el); });
  }

  /* ---------- Service card accordion ---------- */
  document.querySelectorAll('[data-service]').forEach(function(card){
    card.addEventListener('click', function(){
      var isOpen = card.getAttribute('aria-expanded') === 'true';
      document.querySelectorAll('[data-service]').forEach(function(c){ c.setAttribute('aria-expanded','false'); });
      card.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
    });
  });

  /* ---------- Portfolio filter ---------- */
  var filterBtns = document.querySelectorAll('.filter-btn');
  var pCards = document.querySelectorAll('.p-card');
  filterBtns.forEach(function(btn){
    btn.addEventListener('click', function(){
      filterBtns.forEach(function(b){ b.classList.remove('active'); });
      btn.classList.add('active');
      var f = btn.getAttribute('data-filter');
      pCards.forEach(function(card){
        var match = f === 'semua' || card.getAttribute('data-category') === f;
        card.setAttribute('data-hidden', match ? 'false' : 'true');
      });
    });
  });

  /* ---------- Generic form validator ---------- */
  function validateForm(fieldsCheck){
    var valid = true;
    fieldsCheck.forEach(function(fc){
      var input = document.getElementById(fc.id);
      if(!input) return;
      var wrap = input.closest('[data-field]');
      var ok = fc.test();
      if(wrap) wrap.classList.toggle('invalid', !ok);
      if(!ok) valid = false;
    });
    return valid;
  }

  /* ---------- Contact form (index.html only) ---------- */
  var contactForm = document.getElementById('contactForm');
  if(contactForm){
    contactForm.addEventListener('submit', function(e){
      e.preventDefault();
      var ok = validateForm([
        { id:'cName', test:function(){ return document.getElementById('cName').value.trim().length > 0; } },
        { id:'cEmail', test:function(){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(document.getElementById('cEmail').value.trim()); } },
        { id:'cCompany', test:function(){ return document.getElementById('cCompany').value.trim().length > 0; } },
        { id:'cMessage', test:function(){ return document.getElementById('cMessage').value.trim().length > 0; } }
      ]);
      if(!ok) return;
      var successEl = document.getElementById('formSuccess');
      if(successEl) successEl.classList.add('show');
      contactForm.reset();
      showToast('Pesan berhasil dikirim (demo lokal — belum terhubung ke email/CRM).');
    });
  }

  /* ---------- Download PDF placeholder (index.html only) ---------- */
  var downloadBtn = document.getElementById('downloadBtn');
  if(downloadBtn){
    downloadBtn.addEventListener('click', function(){
      showToast('Company profile PDF akan tersedia di sini setelah file final diupload.');
    });
  }

  /* ---------- WhatsApp links ---------- */
  var waFloatMain = document.getElementById('waFloatMain');
  if(waFloatMain) waFloatMain.href = 'https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent('Halo, saya ingin bertanya tentang layanan Berjaya Sukses Makmur.');

  var waFloatCampaign = document.getElementById('waFloatCampaign');
  if(waFloatCampaign) waFloatCampaign.href = 'https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent('Halo, saya tertarik dengan promo survey gratis instalasi listrik.');

  var waCampaignBtn = document.getElementById('waCampaignBtn');
  if(waCampaignBtn) waCampaignBtn.href = 'https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent('Halo, saya tertarik dengan promo survey gratis instalasi listrik.');

  /* ---------- Lead form (kampanye-instalasi-listrik.html only) ---------- */
  var leadForm = document.getElementById('leadFormEl');
  if(leadForm){
    leadForm.addEventListener('submit', function(e){
      e.preventDefault();
      var ok = validateForm([
        { id:'lName', test:function(){ return document.getElementById('lName').value.trim().length > 0; } },
        { id:'lPhone', test:function(){ return document.getElementById('lPhone').value.trim().length >= 8; } },
        { id:'lType', test:function(){ return document.getElementById('lType').value.trim().length > 0; } },
        { id:'lLoc', test:function(){ return document.getElementById('lLoc').value.trim().length > 0; } }
      ]);
      if(!ok) return;
      var name = document.getElementById('lName').value.trim();
      var phone = document.getElementById('lPhone').value.trim();
      var type = document.getElementById('lType').value;
      var loc = document.getElementById('lLoc').value.trim();
      var msg = 'Halo, saya ' + name + ' (' + phone + ') ingin minta penawaran untuk ' + type + ' di ' + loc + '.';
      var leadSuccessEl = document.getElementById('leadSuccess');
      if(leadSuccessEl) leadSuccessEl.classList.add('show');
      leadForm.reset();
      showToast('Permintaan tersimpan (demo lokal). Klik WhatsApp untuk lanjutkan.');
      if(waCampaignBtn) waCampaignBtn.href = 'https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent(msg);
    });
  }
})();
