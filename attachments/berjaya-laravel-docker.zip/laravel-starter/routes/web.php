<?php

use App\Http\Controllers\SiteController;
use App\Http\Controllers\ContactController;
use Illuminate\Support\Facades\Route;

Route::get('/', [SiteController::class, 'home'])->name('home');
Route::get('/kampanye-instalasi-listrik', [SiteController::class, 'campaign'])->name('campaign.instalasi-listrik');
Route::post('/contact', [ContactController::class, 'store'])->name('contact.store');
Route::post('/leads', [ContactController::class, 'storeLead'])->name('leads.store');
