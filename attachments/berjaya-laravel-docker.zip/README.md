# Menjalankan Website Berjaya (versi Laravel) via Docker

Karena Docker sudah terpasang, kamu TIDAK perlu install PHP, Composer, MySQL, atau Node
satu-satu di laptop. Semua itu sudah dibungkus di dalam container.

## Langkah

1. Buka terminal/cmd, masuk ke folder ini (folder yang isinya docker-compose.yml).
2. Jalankan:

   docker compose up --build

   Build pertama kali agak lama (php artisan project dibuat, composer install, migration) —
   tunggu sampai muncul log "Siap! Membuka server di http://localhost:8000".
3. Buka browser ke: http://localhost:8000

Selesai — tidak ada langkah lain.

## Yang terjadi di balik layar

- Container `db` menjalankan MySQL 8.
- Container `app` otomatis: membuat project Laravel baru (`composer create-project`),
  menyalin file dari folder `laravel-starter/` (model, migration, controller, view,
  CSS/JS/logo asli), generate `.env`, migrate database, isi data contoh, lalu
  menjalankan `php artisan serve`.
- Project Laravel hasil generate otomatis muncul di folder `laravel-app/` di komputer kamu
  (bukan terkunci di dalam container) — jadi bisa langsung dibuka & diedit pakai
  code editor apa pun (VS Code, dst).

## Perintah yang sering dipakai

- Jalankan di background: `docker compose up -d --build`
- Lihat log: `docker compose logs -f app`
- Masuk ke shell container app (untuk jalankan artisan command manual, dsb):
  `docker compose exec app sh`
  lalu di dalamnya misalnya: `php artisan migrate:fresh --seed`
- Matikan semua container: `docker compose down`
- Matikan + hapus juga data MySQL: `docker compose down -v`

## Kalau mau install Filament (admin/CRM) setelah container jalan

  docker compose exec app sh
  composer require filament/filament
  php artisan filament:install --panels
  php artisan make:filament-user
  php artisan make:filament-resource Certification
  php artisan make:filament-resource Testimonial
  php artisan make:filament-resource ClientLogo

Lalu buka http://localhost:8000/admin

## Catatan jujur

Saya susun ini dengan pola standar Laravel+Docker yang umum dipakai, tapi tidak bisa saya
jalankan/test end-to-end di sisi saya (sandbox saya tidak punya akses ke Packagist/registry
Composer). Kemungkinan besar jalan langsung, tapi kalau ada error saat build pertama kali,
copy pesan errornya ke saya — saya bantu debug.

Halaman yang sudah dikonversi ke Blade dan otomatis dinamis dari database baru "Home" —
section lain (Services, Legalitas, Galeri, dst.) masih perlu dikonversi menyusul pola yang
sama seperti di resources/views/home.blade.php.
