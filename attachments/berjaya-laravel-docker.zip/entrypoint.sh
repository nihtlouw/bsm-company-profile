#!/bin/sh
set -e

cd /var/www/html

if [ ! -f artisan ]; then
  echo ">> Membuat project Laravel baru (sekali saja, butuh koneksi internet)..."
  composer create-project laravel/laravel . --prefer-dist --no-interaction
fi

echo ">> Menyalin file starter (model, migration, controller, view, aset)..."
mkdir -p app/Models app/Http/Controllers app/Filament/Resources database/migrations database/seeders routes resources/views public
cp -rf /starter/app/. app/
cp -rf /starter/database/. database/
cp -rf /starter/resources/. resources/
cp -rf /starter/routes/. routes/
cp -rf /starter/public/. public/

if [ ! -f .env ]; then
  cp .env.example .env
fi

sed -i "s/^DB_CONNECTION=.*/DB_CONNECTION=mysql/" .env
sed -i "s/^DB_HOST=.*/DB_HOST=${DB_HOST}/" .env
sed -i "s/^DB_PORT=.*/DB_PORT=3306/" .env
sed -i "s/^DB_DATABASE=.*/DB_DATABASE=${DB_DATABASE}/" .env
sed -i "s/^DB_USERNAME=.*/DB_USERNAME=${DB_USERNAME}/" .env
sed -i "s/^DB_PASSWORD=.*/DB_PASSWORD=${DB_PASSWORD}/" .env

php artisan key:generate --force

echo ">> Menjalankan migration..."
php artisan migrate --force

if [ ! -f storage/.seeded ]; then
  echo ">> Mengisi data contoh..."
  php artisan db:seed --class="Database\\Seeders\\ProjectSeeder" --force || true
  touch storage/.seeded
fi

echo ">> Siap! Membuka server di http://localhost:8000"
php artisan serve --host=0.0.0.0 --port=8000
